
--- The number below is the debug revision number.
--- It is used in migrations.lua to determine if any migrations need to be run for beta testers.
--- It is expected these are only meaningful between releases during beta testing.
--- It should be set to nil for any release version.
return nil
