both_wagon_sprite = {
	type = "sprite",
	name = "cybersyn-both-wagon",
	filename = "__cybersyn__/graphics/icons/both-wagon.png",
	size = 64,
	scale = 0.5,
	flags = { "gui-icon" }
}
