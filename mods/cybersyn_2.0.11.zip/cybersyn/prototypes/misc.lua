
missing_train_icon = flib.copy_prototype(data.raw["fluid"]["water"], MISSING_TRAIN_NAME)
missing_train_icon.icon = "__cybersyn__/graphics/icons/missing-train.png"
missing_train_icon.icon_size = 64
missing_train_icon.icon_mipmaps = 0
missing_train_icon.hidden = true
missing_train_icon.auto_barrel = false
missing_train_icon.subgroup = "cybersyn-signal"

lost_train_icon = flib.copy_prototype(data.raw["fluid"]["water"], LOST_TRAIN_NAME)
lost_train_icon.icon = "__cybersyn__/graphics/icons/lost-train.png"
lost_train_icon.icon_size = 64
lost_train_icon.icon_mipmaps = 0
lost_train_icon.hidden = true
lost_train_icon.auto_barrel = false
lost_train_icon.subgroup = "cybersyn-signal"

nonempty_train_icon = flib.copy_prototype(data.raw["fluid"]["water"], NONEMPTY_TRAIN_NAME)
nonempty_train_icon.icon = "__cybersyn__/graphics/icons/nonempty-train.png"
nonempty_train_icon.icon_size = 64
nonempty_train_icon.icon_mipmaps = 0
nonempty_train_icon.hidden = true
nonempty_train_icon.auto_barrel = false
nonempty_train_icon.subgroup = "cybersyn-signal"
